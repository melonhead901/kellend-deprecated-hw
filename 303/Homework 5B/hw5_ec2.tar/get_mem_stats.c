// Group F - Kellen Donohue and Zach Stein
// CSE 303 - Assignment 5
// 02-25-09

#include "stdafx.h"
#include "mem.h"
#include "mem_impl.h"

// Calculates various statistics about the memory
void get_mem_stats(int* total_size, int* total_free, int* n_free_blocks) {
  extern struct memblock* front;
  extern int* bytes_acquired;

  // Remember where we are in the freelist
  struct memblock* block = front;
  
  // Local vairables to track cumulative size and bumber of blocks
  int t_free = 0;
  int n_free = 0;
  
  // Iterate through the freelist updating #block and size at each block
  while (block)
  {
    t_free += sizeof(struct memblock) + block->size;
    n_free += 1;
    block = block->next;
  }
  
  *total_free = t_free;
  *n_free_blocks = n_free;  
  *total_size = *bytes_acquired;
}
