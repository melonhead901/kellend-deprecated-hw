// Group F - Kellen Donohue and Zach Stein
// CSE 303 - Assignment 5
// 02-25-09

#include "stdafx.h"
#include "mem.h"
#include <time.h>
// suggested we use - getopt, rand / srand, time, clock

#define NUM_STATISTICS_PRINTED 10

int main(int argc, char** argv)
{
  int ntrials = 10000; //Number of trials to preform
  int pctget = 50; // Change of getting a new value versus freeing the old one
  int pctlarge = 10; // Change of picking a large block
  int small_limit = 200; // Highest value a small block can be
  int large_limit = 20000; // Highest value a large block can be
  time_t random_seed = time(NULL); // The random seed used throughout the loop
  int i; // loop counter
  int t; // temp storage for debug info
  double print_after_percent = 1.0 / NUM_STATISTICS_PRINTED;
  
  int** blocks = (int**)malloc(ntrials * sizeof(int*)); // blocks gotten from getmem
  int block_count = 0;
  int bytes_acquired_by_mm = 0; // stores number of bytes acquired by the m.m. so far
  int free_blocks; // stores number of free blocks on the free list
  int bytes_free; // stores number of bytes on the free list

  for (i = 1; i < argc; i++)
  { // argument handling
    switch(i)
    {
    case 1: ntrials = atoi(argv[i]); break;
    case 2: pctget = atoi(argv[i]); break;
    case 3: pctlarge = atoi(argv[i]); break;
    case 4: small_limit = atoi(argv[i]); break;
    case 5: large_limit = atoi(argv[i]); break;
    case 6: random_seed = atoi(argv[i]); break;
    }
  }

  #ifdef DEBUG 
  printf("seed: %d", (int)random_seed); // print the random seed used
  #endif

  srand(random_seed); // Randomize the seed

  for (i = 0; i < ntrials; i++)
  { 
    #ifdef DEBUG
    printf("\ntrial %d: ", i + 1); // print trial number
    #endif
    
    // Get a new block
    t = 1 + rand() % 100;
    if (t <= pctget)
    { 
      t = 1 + rand() % 100;
      if (t <= pctlarge)
      {
        t = 1 + small_limit + rand() % (large_limit - small_limit);
        blocks[block_count] = getmem(t);
        
	#if DEBUG
	// print size of large block being allocated
	printf("getting a large block of size %d\n", t);
	#endif
      }
      else
      {
        t = 1 + rand() % small_limit;
        blocks[block_count] = getmem(t);
	
	#if DEBUG
	// print size of small block being allocated
        printf("getting a small block of size %d\n", t);
	#endif
      }
      block_count++;
    }
    // Free a block
    else {
      // Do nothing if no blocks left to free
      if (block_count > 0)
      { 
        // Free a random block, replacing it with the block at the end of the list
        int to_free = rand() % block_count;
       
	#ifdef DEBUG
	printf("freeing block number %d\n", to_free + 1); // print block number being freeing
        #endif

	freemem(blocks[to_free]);
        blocks[to_free] = blocks[block_count - 1];
        block_count--;
      }
      else
      {
	#ifdef DEBUG
        printf("no blocks to free\n"); // print no blocks allocated to free
	#endif
      }
    }
    //print info about mem manager 10 times
    if (i >= (ntrials - 1) * print_after_percent){
      get_mem_stats(&bytes_acquired_by_mm, &bytes_free, &free_blocks);
      printf("%f seconds, %d bytes acquired by mm, %d free blocks, %d bytes/block on average\n",
	     (float)clock() / (float)CLOCKS_PER_SEC, bytes_acquired_by_mm, free_blocks, bytes_free / free_blocks);

      print_after_percent += 1.0 / NUM_STATISTICS_PRINTED;
    }

    #ifdef DEBUG
    printf("number unfreed blocks: %d\n", block_count); // print num blocks being held
    printf("free list (block, size, next):\n");
    print_heap(stdout); // print free list
    #endif
  }

  return 0;
}
