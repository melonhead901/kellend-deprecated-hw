// Group F - Kellen Donohue and Zach Stein
// CSE 303 - Assignment 5
// 02-25-09

#include "stdafx.h"
#include "mem_impl_ec.h"

// Returns a pointer to a new block with at least size bytes of memory
void* getmem(int size)
{
  // Size must be positive
  if(size > 0)
  {
    extern struct memblock* front;
    extern struct memblock* last;

    // Keep track of the node you are on and the previous node you checked
    struct memblock* node = front;
    struct memblock* previous = NULL;

    // Correct size to be a multiple of eight if it isn't
    if(size%DESIREDBLOCKMULTIPLE != 0)
    {
      size = size + DESIREDBLOCKMULTIPLE - size%DESIREDBLOCKMULTIPLE;
      assert (size%DESIREDBLOCKMULTIPLE == 0);
    }

    if (front == NULL)
    {
      // Don't need to place a new block, just get a new one and add it at the front
      front = getNewBlock(size);
      node = front;
      last = front;
    }

    assert(front);
    assert(node);
    assert(last);

    // Go through the list and find the first block that's big enough
    while(node)
    {
      // You found a node of the right size
      if(size <= node->size)
      {
        if(node->size - size > TOLERANCE)  // If the block is too big, subdivide it
        {
          splitBlock(node, size);
          last = node->next;
        }
        if(previous) // remove node from the middle free list
        {
          previous->next = node->next;
          last = previous;
          if(node->next)
          { 
            node->next->previous = previous;
          }
        }
        else // You are removing the block at the front of the list
        {
          front = node->next;
          if(front) // If there's only 1 value on the freelist at this point
          {
            front->previous = NULL;
          }
          last = front;
        }
        return node + 1;
      }
      // Get the next node
      previous = node;
      node = node->next;
    }

    // Go through the list again starting at the top
    node = front;
    while(node && node < last)
    {
      // You found a node of the right size
      if(size <= node->size)
      {
        if(node->size - size > TOLERANCE)  // If the block is too big, subdivide it
        {
          splitBlock(node, size);
          last = node->next;
        }
        if(previous) // remove node from the free list
        {
          previous->next = node->next;
          last = previous;
          if(node->next)
          {
            node->next->previous = previous;
          }
        }
        else // You are removing the block at the front of the list
        {
          front = node->next;
          if(front) // If there's only 1 value on the freelist at this point
          {
            front->previous = NULL;
          }
          last = front;
        }
        return node + 1;
      }      
      // Get the next node
      previous = node;
      node = node->next;
    }

    // No block was big enough, get a new one and place it in the list
    placeNewBlock(size, front);

    return getmem(size);
  }

  return NULL;

  // Stub implementation
  // return malloc(size);
}

void placeNewBlock(int size, struct memblock* node)
{
  struct memblock* previous = NULL; 
  struct memblock* newBlock = getNewBlock(size);

  while (node && node < newBlock) // Go to the right place in the freelist based on newBlock
  {
    previous = node;
    node = node->next;
  }
  if (node == NULL) // newBlock is at the end of the list
  {
    previous->next = newBlock;
  }
  else if (previous == NULL) // newBlock is at the beginning of the list
  {
    newBlock->next = front;    
    front = newBlock;
  }
  else // newBlock is somewhere inside the list
  {
    newBlock->next = node;
    previous->next = newBlock;
  }

  newBlock->previous = previous;
  if(node)
  {
    node->previous = newBlock;
  }
  last=newBlock;
}

// Splits the given block at size given, returning a point to the second block
void splitBlock(struct memblock *block, int size)
{
  struct memblock* newNode;
  assert(block->size + sizeof(struct memblock) > size);

  // Create new block
  newNode = (struct memblock*)((int)(block + 1) + size);
  newNode->next = block->next;
  newNode->size = block->size - (size + sizeof(struct memblock));
  newNode->previous = block;

  // Update first block
  block->next = newNode;
  block->size = size;
}

// Returns a pointer to a node with the size field initialized that is at least big enough to hold min_size
struct memblock* getNewBlock(int min_size)
{
  extern int* bytes_acquired;
  struct memblock* node;
  int sizeToMalloc; 

  // If the requested block is bigger than the standard block size get a larger block
  if (min_size + sizeof(struct memblock) > DEFAULTBLOCKSIZE)
  { 
    sizeToMalloc = min_size + sizeof(struct memblock);
    node = malloc(sizeToMalloc);
    node->size = min_size;
  }

  // Otherwise use the default size
  else
  {    
    sizeToMalloc = DEFAULTBLOCKSIZE;
    node = malloc(sizeToMalloc);
    node->size = DEFAULTBLOCKSIZE - sizeof(struct memblock);
  }

  if(!bytes_acquired)
  {
    bytes_acquired = (int*)malloc(sizeof(int));
    *bytes_acquired = 0;
  }
  else
  {
    *bytes_acquired += sizeToMalloc;
  }
  node->next = NULL;  
  node->previous = NULL;
  node->previous = NULL;
  return node;
}
