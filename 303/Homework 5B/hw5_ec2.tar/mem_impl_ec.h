// Group F - Kellen Donohue and Zach Stein
// CSE 303 - Assignment 5
// 02-25-09

#ifndef MEM_IMPL_EC_H
#define MEM_IMPL_EC_H

#include "stdafx.h"

// Default size for the block to get from malloc (4KB = 4096 bytes)
#define DEFAULTBLOCKSIZE 4096

// Subdivide the memory block if it the resquested size is this amount larger than the given block
#define TOLERANCE 512

// Desired block multiple size
#define DESIREDBLOCKMULTIPLE 8

// The variable at the front of the free list
struct memblock* front;

// The last value returned by getmem
struct memblock* last;

// Total number of bytes acquired from the underlying structure
int *bytes_acquired;

// The memblock data structure
struct memblock
{
  // The size of the data in the memblock, not including the header
  int size;
  
  // The point to the next header of the memblock in the freelist, if the memblock is in the freelist
  struct memblock* next;

  // Points to the block before this one when memblock was put on the freelist
  struct memblock* previous;
};

// Splits the given block at size given, returning a point to the second block
void splitBlock(struct memblock* block, int size);

// Get a new block from the underlying system (malloc), returning the new block
struct memblock* getNewBlock(int min_size);

// Combines two blocks if they are adjacent, returning 1, otherwise 0
void combineIfAdj(struct memblock* b1, struct memblock* b2);

// Gets a new block and places it in the list
void placeNewBlock(int size, struct memblock* node);

#endif
