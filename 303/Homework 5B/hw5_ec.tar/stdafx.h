// Group F - Kellen Donohue and Zach Stein
// CSE 303 - Assignment 5
// 02-25-09

#ifndef STDAFX_H
#define STDAFX_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

#endif
