// Group F - Kellen Donohue and Zach Stein
// CSE 303 - Assignment 5
// 02-25-09

#include "stdafx.h"
#include "mem_impl_ec.h"

// Adds the block of storage at location p to the free list
// Undefined if p has already been freed by freemem or wasn't obtained by getmem
void freemem(void* p){
  if(p) { // do nothing if p is null
    extern struct memblock* front; // front of the free list
    struct memblock* p_header = (struct memblock*) p - 1; // header for p

    if (!front || p_header < front){ // if p is before front
      p_header->next = front;
      front = p_header;

      // combine p w/ following block if they are adjacent
      combineIfAdj(p_header, p_header->next);

    }
    else { // else p is after front
      struct memblock* block_before = front; // the free block before p
      while ((int)block_before + sizeof(struct memblock) + block_before->size < (int)p_header)
      {
        if(block_before->next == NULL) break;
        else if (block_before->next < p_header) // move forward through the free list
        {
          block_before = block_before->next;
        }
        else break; // until block_before is the block before p
      }

      // update the next field for p_header and block_before
      p_header->next = block_before->next;
      block_before->next = p_header;

      // combine p w/ following block if they are adjacent
      // this must happen before combining it with the block before
      combineIfAdj(p_header, p_header->next);

      // combine p w/ block before if they are adjacent
      combineIfAdj(block_before, p_header);
    }
  }
}

void combineIfAdj(struct memblock* b1, struct memblock* b2)
{
  if((int)b1 + b1->size + sizeof(struct memblock) == (int)b2)
  {
    b1->next = b2->next;
    b1->size += sizeof(struct memblock) + b2->size;
  }
}
