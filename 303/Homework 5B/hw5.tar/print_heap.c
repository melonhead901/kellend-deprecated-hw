// Group F - Kellen Donohue and Zach Stein
// CSE 303 - Assignment 5
// 02-25-09

#include "stdafx.h"
#include "mem_impl.h"

// Prints a formatted listing of free list to file f
void print_heap(FILE* f)
{
  extern struct memblock* front;	
  struct memblock* node = front;
  // While there is still a node on the list print the node
  while(node)
  {
    fprintf(f, "%p %d %p\n", node, node->size, node->next);
    node = node->next;
  }
}
