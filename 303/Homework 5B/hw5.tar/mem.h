// Group F - Kellen Donohue and Zach Stein
// CSE 303 - Assignment 5
// 02-25-09

#ifndef MEM_H
#define MEM_H

// Returns a pointer to a new block with at least size bize of memory
void* getmem(int size);

// Adds the block of storage at location p to the free list
void freemem(void* p);

// Calculates various statistics about the memory
void get_mem_stats(int* total_size, int* total_free, int* n_free_blocks);

// Prints a formatted listing of free list to file f
void print_heap(FILE* f);

#endif
